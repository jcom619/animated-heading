#!/bin/sh
# NightLion v1
printf "\033]4;0;#4c4c4c;1;#bb0000;2;#5fde8f;3;#f3f167;4;#276bd8;5;#bb00bb;6;#00dadf;7;#bbbbbb;8;#555555;9;#ff5555;10;#55ff55;11;#ffff55;12;#5555ff;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#bbbbbb;#000000;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#e3e3e3\007"
