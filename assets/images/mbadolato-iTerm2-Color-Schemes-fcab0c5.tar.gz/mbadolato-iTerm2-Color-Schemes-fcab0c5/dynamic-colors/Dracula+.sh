#!/bin/sh
# Dracula+
printf "\033]4;0;#21222c;1;#ff5555;2;#50fa7b;3;#ffcb6b;4;#82aaff;5;#c792ea;6;#8be9fd;7;#f8f8f2;8;#545454;9;#ff6e6e;10;#69ff94;11;#ffcb6b;12;#d6acff;13;#ff92df;14;#a4ffff;15;#f8f8f2\007"
printf "\033]10;#f8f8f2;#212121;#eceff4\007"
printf "\033]17;#f8f8f2\007"
printf "\033]19;#545454\007"
printf "\033]5;0;#ffffff\007"
