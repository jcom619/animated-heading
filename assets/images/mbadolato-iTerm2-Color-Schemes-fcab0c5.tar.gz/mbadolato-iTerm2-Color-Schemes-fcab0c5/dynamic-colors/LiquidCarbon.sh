#!/bin/sh
# LiquidCarbon
printf "\033]4;0;#000000;1;#ff3030;2;#559a70;3;#ccac00;4;#0099cc;5;#cc69c8;6;#7ac4cc;7;#bccccc;8;#000000;9;#ff3030;10;#559a70;11;#ccac00;12;#0099cc;13;#cc69c8;14;#7ac4cc;15;#bccccc\007"
printf "\033]10;#afc2c2;#303030;#ffffff\007"
printf "\033]17;#7dbeff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
