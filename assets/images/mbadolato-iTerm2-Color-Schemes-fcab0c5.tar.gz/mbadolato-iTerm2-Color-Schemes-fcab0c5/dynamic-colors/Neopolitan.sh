#!/bin/sh
# Neopolitan
printf "\033]4;0;#000000;1;#800000;2;#61ce3c;3;#fbde2d;4;#253b76;5;#ff0080;6;#8da6ce;7;#f8f8f8;8;#000000;9;#800000;10;#61ce3c;11;#fbde2d;12;#253b76;13;#ff0080;14;#8da6ce;15;#f8f8f8\007"
printf "\033]10;#ffffff;#271f19;#ffffff\007"
printf "\033]17;#253b76\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
