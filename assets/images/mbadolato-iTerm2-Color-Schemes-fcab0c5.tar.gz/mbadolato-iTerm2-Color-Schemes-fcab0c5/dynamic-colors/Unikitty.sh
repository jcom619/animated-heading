#!/bin/sh
# Unikitty
printf "\033]4;0;#0c0c0c;1;#a80f20;2;#bafc8b;3;#eedf4b;4;#145fcd;5;#ff36a2;6;#6bd1bc;7;#e2d7e1;8;#434343;9;#d91329;10;#d3ffaf;11;#ffef50;12;#0075ea;13;#fdd5e5;14;#79ecd5;15;#fff3fe\007"
printf "\033]10;#0b0b0b;#ff8cd9;#bafc8b\007"
printf "\033]17;#3ea9fe\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#000000\007"
