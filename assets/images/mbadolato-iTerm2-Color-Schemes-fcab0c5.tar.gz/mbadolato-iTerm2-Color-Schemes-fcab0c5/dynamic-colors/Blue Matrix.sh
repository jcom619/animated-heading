#!/bin/sh
# Blue Matrix
printf "\033]4;0;#101116;1;#ff5680;2;#00ff9c;3;#fffc58;4;#00b0ff;5;#d57bff;6;#76c1ff;7;#c7c7c7;8;#686868;9;#ff6e67;10;#5ffa68;11;#fffc67;12;#6871ff;13;#d682ec;14;#60fdff;15;#ffffff\007"
printf "\033]10;#00a2ff;#101116;#76ff9f\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#00ffc8\007"
