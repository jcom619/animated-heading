#!/bin/sh
# WildCherry
printf "\033]4;0;#000507;1;#d94085;2;#2ab250;3;#ffd16f;4;#883cdc;5;#ececec;6;#c1b8b7;7;#fff8de;8;#009cc9;9;#da6bac;10;#f4dca5;11;#eac066;12;#308cba;13;#ae636b;14;#ff919d;15;#e4838d\007"
printf "\033]10;#dafaff;#1f1726;#dd00ff\007"
printf "\033]17;#002831\007"
printf "\033]19;#e4ffff\007"
printf "\033]5;0;#819090\007"
