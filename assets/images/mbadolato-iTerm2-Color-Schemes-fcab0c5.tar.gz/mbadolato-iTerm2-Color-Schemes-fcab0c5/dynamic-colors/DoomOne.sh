#!/bin/sh
# DoomOne
printf "\033]4;0;#000000;1;#ff6c6b;2;#98be65;3;#ecbe7b;4;#a9a1e1;5;#c678dd;6;#51afef;7;#bbc2cf;8;#000000;9;#ff6655;10;#99bb66;11;#ecbe7b;12;#a9a1e1;13;#c678dd;14;#51afef;15;#bfbfbf\007"
printf "\033]10;#bbc2cf;#282c34;#51afef\007"
printf "\033]17;#42444b\007"
printf "\033]19;#bbc2cf\007"
printf "\033]5;0;#bbc2cf\007"
