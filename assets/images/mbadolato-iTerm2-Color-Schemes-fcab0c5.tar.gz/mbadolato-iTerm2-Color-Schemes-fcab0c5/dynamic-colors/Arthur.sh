#!/bin/sh
# Arthur
printf "\033]4;0;#3d352a;1;#cd5c5c;2;#86af80;3;#e8ae5b;4;#6495ed;5;#deb887;6;#b0c4de;7;#bbaa99;8;#554444;9;#cc5533;10;#88aa22;11;#ffa75d;12;#87ceeb;13;#996600;14;#b0c4de;15;#ddccbb\007"
printf "\033]10;#ddeedd;#1c1c1c;#e2bbef\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
