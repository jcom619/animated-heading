#!/bin/sh
# Espresso Libre
printf "\033]4;0;#000000;1;#cc0000;2;#1a921c;3;#f0e53a;4;#0066ff;5;#c5656b;6;#06989a;7;#d3d7cf;8;#555753;9;#ef2929;10;#9aff87;11;#fffb5c;12;#43a8ed;13;#ff818a;14;#34e2e2;15;#eeeeec\007"
printf "\033]10;#b8a898;#2a211c;#ffffff\007"
printf "\033]17;#c3dcff\007"
printf "\033]19;#b8a898\007"
printf "\033]5;0;#d3c1af\007"
