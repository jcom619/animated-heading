#!/bin/sh
# ENCOM
printf "\033]4;0;#000000;1;#9f0000;2;#008b00;3;#ffd000;4;#0081ff;5;#bc00ca;6;#008b8b;7;#bbbbbb;8;#555555;9;#ff0000;10;#00ee00;11;#ffff00;12;#0000ff;13;#ff00ff;14;#00cdcd;15;#ffffff\007"
printf "\033]10;#00a595;#000000;#bbbbbb\007"
printf "\033]17;#00a48c\007"
printf "\033]19;#3de1c9\007"
printf "\033]5;0;#4cf1e1\007"
