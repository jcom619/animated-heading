#!/bin/sh
# Aurora
printf "\033]4;0;#23262e;1;#f0266f;2;#8fd46d;3;#ffe66d;4;#0321d7;5;#ee5d43;6;#03d6b8;7;#c74ded;8;#292e38;9;#f92672;10;#8fd46d;11;#ffe66d;12;#03d6b8;13;#ee5d43;14;#03d6b8;15;#c74ded\007"
printf "\033]10;#ffca28;#23262e;#ee5d43\007"
printf "\033]17;#292e38\007"
printf "\033]19;#00e8c6\007"
printf "\033]5;0;#fbfbff\007"
