#!/bin/sh
# Floraverse
printf "\033]4;0;#08002e;1;#64002c;2;#5d731a;3;#cd751c;4;#1d6da1;5;#b7077e;6;#42a38c;7;#f3e0b8;8;#331e4d;9;#d02063;10;#b4ce59;11;#fac357;12;#40a4cf;13;#f12aae;14;#62caa8;15;#fff5db\007"
printf "\033]10;#dbd1b9;#0e0d15;#bbbbbb\007"
printf "\033]17;#f3e0b8\007"
printf "\033]19;#08002e\007"
printf "\033]5;0;#ffffff\007"
