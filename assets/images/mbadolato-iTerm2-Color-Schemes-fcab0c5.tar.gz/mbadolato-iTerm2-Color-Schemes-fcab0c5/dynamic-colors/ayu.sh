#!/bin/sh
# ayu
printf "\033]4;0;#000000;1;#ff3333;2;#b8cc52;3;#e7c547;4;#36a3d9;5;#f07178;6;#95e6cb;7;#ffffff;8;#323232;9;#ff6565;10;#eafe84;11;#fff779;12;#68d5ff;13;#ffa3aa;14;#c7fffd;15;#ffffff\007"
printf "\033]10;#e6e1cf;#0f1419;#f29718\007"
printf "\033]17;#253340\007"
printf "\033]19;#e6e1cf\007"
printf "\033]5;0;#e6e1cf\007"
