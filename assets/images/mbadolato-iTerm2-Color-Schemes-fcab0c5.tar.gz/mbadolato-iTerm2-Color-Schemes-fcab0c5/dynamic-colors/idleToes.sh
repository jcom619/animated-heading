#!/bin/sh
# idleToes
printf "\033]4;0;#323232;1;#d25252;2;#7fe173;3;#ffc66d;4;#4099ff;5;#f680ff;6;#bed6ff;7;#eeeeec;8;#535353;9;#f07070;10;#9dff91;11;#ffe48b;12;#5eb7f7;13;#ff9dff;14;#dcf4ff;15;#ffffff\007"
printf "\033]10;#ffffff;#323232;#d6d6d6\007"
printf "\033]17;#5b5b5b\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffa9\007"
