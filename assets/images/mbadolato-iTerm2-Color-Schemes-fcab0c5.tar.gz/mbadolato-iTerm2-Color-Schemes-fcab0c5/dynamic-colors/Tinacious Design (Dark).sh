#!/bin/sh
# Tinacious Design (Dark)
printf "\033]4;0;#1d1d26;1;#ff3399;2;#00d364;3;#ffcc66;4;#00cbff;5;#cc66ff;6;#00ceca;7;#cbcbf0;8;#636667;9;#ff2f92;10;#00d364;11;#ffd479;12;#00cbff;13;#d783ff;14;#00d5d4;15;#d5d6f3\007"
printf "\033]10;#cbcbf0;#1d1d26;#cbcbf0\007"
printf "\033]17;#ff3399\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
