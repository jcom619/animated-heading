#!/bin/sh
# Mathias
printf "\033]4;0;#000000;1;#e52222;2;#a6e32d;3;#fc951e;4;#c48dff;5;#fa2573;6;#67d9f0;7;#f2f2f2;8;#555555;9;#ff5555;10;#55ff55;11;#ffff55;12;#5555ff;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#bbbbbb;#000000;#bbbbbb\007"
printf "\033]17;#555555\007"
printf "\033]19;#f2f2f2\007"
printf "\033]5;0;#ffffff\007"
