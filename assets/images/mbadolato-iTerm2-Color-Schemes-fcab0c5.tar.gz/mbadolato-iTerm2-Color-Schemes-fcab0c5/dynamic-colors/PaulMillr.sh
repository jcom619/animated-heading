#!/bin/sh
# PaulMillr
printf "\033]4;0;#2a2a2a;1;#ff0000;2;#79ff0f;3;#e7bf00;4;#396bd7;5;#b449be;6;#66ccff;7;#bbbbbb;8;#666666;9;#ff0080;10;#66ff66;11;#f3d64e;12;#709aed;13;#db67e6;14;#7adff2;15;#ffffff\007"
printf "\033]10;#f2f2f2;#000000;#4d4d4d\007"
printf "\033]17;#414141\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
