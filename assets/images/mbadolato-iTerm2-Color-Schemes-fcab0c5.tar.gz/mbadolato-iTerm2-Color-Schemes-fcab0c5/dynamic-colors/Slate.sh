#!/bin/sh
# Slate
printf "\033]4;0;#222222;1;#e2a8bf;2;#81d778;3;#c4c9c0;4;#264b49;5;#a481d3;6;#15ab9c;7;#02c5e0;8;#ffffff;9;#ffcdd9;10;#beffa8;11;#d0ccca;12;#7ab0d2;13;#c5a7d9;14;#8cdfe0;15;#e0e0e0\007"
printf "\033]10;#35b1d2;#222222;#87d3c4\007"
printf "\033]17;#0f3754\007"
printf "\033]19;#2dffc0\007"
printf "\033]5;0;#648890\007"
