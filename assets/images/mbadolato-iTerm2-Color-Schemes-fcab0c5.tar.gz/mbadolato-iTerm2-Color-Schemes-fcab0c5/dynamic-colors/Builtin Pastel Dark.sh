#!/bin/sh
# Builtin Pastel Dark
printf "\033]4;0;#4f4f4f;1;#ff6c60;2;#a8ff60;3;#ffffb6;4;#96cbfe;5;#ff73fd;6;#c6c5fe;7;#eeeeee;8;#7c7c7c;9;#ffb6b0;10;#ceffac;11;#ffffcc;12;#b5dcff;13;#ff9cfe;14;#dfdffe;15;#ffffff\007"
printf "\033]10;#bbbbbb;#000000;#ffa560\007"
printf "\033]17;#363983\007"
printf "\033]19;#f2f2f2\007"
printf "\033]5;0;#ffffff\007"
