#!/bin/sh
# Laser
printf "\033]4;0;#626262;1;#ff8373;2;#b4fb73;3;#09b4bd;4;#fed300;5;#ff90fe;6;#d1d1fe;7;#f1f1f1;8;#8f8f8f;9;#ffc4be;10;#d6fcba;11;#fffed5;12;#f92883;13;#ffb2fe;14;#e6e7fe;15;#ffffff\007"
printf "\033]10;#f106e3;#030d18;#00ff9c\007"
printf "\033]17;#2e206a\007"
printf "\033]19;#f4f4f4\007"
printf "\033]5;0;#ffffff\007"
