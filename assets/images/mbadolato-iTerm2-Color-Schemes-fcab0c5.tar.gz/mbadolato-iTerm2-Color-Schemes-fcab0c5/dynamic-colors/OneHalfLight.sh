#!/bin/sh
# OneHalfLight
printf "\033]4;0;#383a42;1;#e45649;2;#50a14f;3;#c18401;4;#0184bc;5;#a626a4;6;#0997b3;7;#fafafa;8;#4f525e;9;#e06c75;10;#98c379;11;#e5c07b;12;#61afef;13;#c678dd;14;#56b6c2;15;#ffffff\007"
printf "\033]10;#383a42;#fafafa;#bfceff\007"
printf "\033]17;#bfceff\007"
printf "\033]19;#383a42\007"
printf "\033]5;0;#abb2bf\007"
