#!/bin/sh
# shades-of-purple
printf "\033]4;0;#000000;1;#d90429;2;#3ad900;3;#ffe700;4;#6943ff;5;#ff2c70;6;#00c5c7;7;#c7c7c7;8;#686868;9;#f92a1c;10;#43d426;11;#f1d000;12;#6871ff;13;#ff77ff;14;#79e8fb;15;#ffffff\007"
printf "\033]10;#ffffff;#1e1d40;#fad000\007"
printf "\033]17;#b362ff\007"
printf "\033]19;#c2c2c2\007"
printf "\033]5;0;#f9fdff\007"
