#!/bin/sh
# IC_Green_PPL
printf "\033]4;0;#014401;1;#ff2736;2;#41a638;3;#76a831;4;#2ec3b9;5;#50a096;6;#3ca078;7;#e6fef2;8;#035c03;9;#b4fa5c;10;#aefb86;11;#dafa87;12;#2efaeb;13;#50fafa;14;#3cfac8;15;#e0f1dc\007"
printf "\033]10;#e0f1dc;#2c2c2c;#47fa6b\007"
printf "\033]17;#116b41\007"
printf "\033]19;#e0f1dc\007"
printf "\033]5;0;#acfb80\007"
