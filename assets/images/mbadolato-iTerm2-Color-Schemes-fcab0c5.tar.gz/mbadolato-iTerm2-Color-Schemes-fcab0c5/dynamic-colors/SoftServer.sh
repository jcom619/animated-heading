#!/bin/sh
# SoftServer
printf "\033]4;0;#000000;1;#a2686a;2;#9aa56a;3;#a3906a;4;#6b8fa3;5;#6a71a3;6;#6ba58f;7;#99a3a2;8;#666c6c;9;#dd5c60;10;#bfdf55;11;#deb360;12;#62b1df;13;#606edf;14;#64e39c;15;#d2e0de\007"
printf "\033]10;#99a3a2;#242626;#d2e0de\007"
printf "\033]17;#7f8786\007"
printf "\033]19;#effffe\007"
printf "\033]5;0;#d2e0de\007"
