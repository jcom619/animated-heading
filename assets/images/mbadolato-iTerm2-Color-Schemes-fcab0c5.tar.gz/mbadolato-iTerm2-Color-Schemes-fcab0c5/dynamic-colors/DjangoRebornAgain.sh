#!/bin/sh
# DjangoRebornAgain
printf "\033]4;0;#000000;1;#fd6209;2;#41a83e;3;#ffe862;4;#245032;5;#f8f8f8;6;#9df39f;7;#ffffff;8;#323232;9;#ff943b;10;#73da70;11;#ffff94;12;#568264;13;#ffffff;14;#cfffd1;15;#ffffff\007"
printf "\033]10;#dadedc;#051f14;#ffcc00\007"
printf "\033]17;#203727\007"
printf "\033]19;#dadedc\007"
printf "\033]5;0;#dadedc\007"
